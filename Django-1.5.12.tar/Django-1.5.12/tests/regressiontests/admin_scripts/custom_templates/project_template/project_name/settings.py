# Django settings for {{ project_name }} test project.
